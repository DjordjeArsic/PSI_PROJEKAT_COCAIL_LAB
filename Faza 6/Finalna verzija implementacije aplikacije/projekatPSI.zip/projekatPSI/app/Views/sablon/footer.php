</div>
  <footer class="bg-dark text-white pt-2 pb-2 align-bottom mt-5">
    <div class="text-center">
      <p class="mb-0">ETF © 2020</p>
    </div>
  </footer>

  <script src="https://kit.fontawesome.com/955e718463.js" crossorigin="anonymous"></script>   
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="<?php echo base_url('/js/popper.min.js'); ?>"></script>
  <script src="<?php echo base_url('/js/bootstrap.min.js'); ?>"></script>
  <script src="<?php echo base_url('/js/moments.min.js'); ?>"></script>
  <script src="<?php echo base_url('/js/bootstrap-datetimepicker.js'); ?>"></script>
  <script src="<?php echo base_url('/js/nouislider.min.js'); ?>"></script>
  <script src="<?php echo base_url('/js/typed.js'); ?>"></script>
  <script src="<?php echo base_url('/js/main.js'); ?>"></script>
</body>
</html>
